package com.example.esp32;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    Button ON, OFF;
    TextView display, display2;
    Boolean connected = false;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ON = findViewById(R.id.Onbutton);
        OFF = findViewById(R.id.Offbutton);
        display = findViewById(R.id.display);
        display2 = findViewById(R.id.display2);

        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            connected = true;
        }
        else {
            connected = false;
        }

        if(!connected) {
            display.setText("No Internet Connection");
            display.setTextColor(Color.RED);
            display.setBackgroundColor(Color.BLACK);
        }
        else {

            // Write a message to the database
            final FirebaseDatabase database = FirebaseDatabase.getInstance();

            final DatabaseReference onlineDbStatus = database.getReference("online");
            onlineDbStatus.setValue(0);

            DatabaseReference myRef = FirebaseDatabase.getInstance().getReference();

            // Read from the database
            myRef.addValueEventListener(new ValueEventListener() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String onlinedb = Objects.requireNonNull(dataSnapshot.child("online").getValue()).toString();
                    String withF34 = Objects.requireNonNull(dataSnapshot.child("F34").getValue()).toString();
                    String withAsus = Objects.requireNonNull(dataSnapshot.child("Asus").getValue()).toString();
                    String doorstatus = Objects.requireNonNull(dataSnapshot.child("status").getValue()).toString();

                    if (Integer.parseInt(onlinedb) == 0) {
                        display.setText("ESP32 is offline");
                        display.setTextColor(Color.RED);
                        display.setBackgroundColor(Color.YELLOW);
                    }

                    if (Integer.parseInt(onlinedb) == 1) {

                        if (Integer.parseInt(withF34) == 1) {
                            display.setText("ESP32 is online with F34");
                            display.setTextColor(Color.BLUE);
                            display.setBackgroundColor(Color.YELLOW);
                        }
                        if (Integer.parseInt(withAsus) == 1) {
                            display.setText("ESP32 is online with Asus");
                            display.setTextColor(Color.BLUE);
                            display.setBackgroundColor(Color.YELLOW);
                        }
                    }

                    if (Integer.parseInt(doorstatus) == 0) {
                        display2.setText("The door is closed");
                        display2.setTextColor(Color.BLUE);
                        display2.setBackgroundColor(Color.GREEN);
                    }

                    if (Integer.parseInt(doorstatus) == 1) {
                        display2.setText("The door is opened");
                        display2.setTextColor(Color.RED);
                        display2.setBackgroundColor(Color.GREEN);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });

            ON.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseReference ledDb = database.getReference("ledDb");
                    ledDb.setValue(1);
                }
            });
            OFF.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DatabaseReference ledDb = database.getReference("ledDb");
                    ledDb.setValue(0);
                }
            });
        }
    }
}